import React, {useEffect, useState} from 'react';
import {View,Text,TextInput,Pressable,FlatList,StyleSheet,Alert,ScrollView} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY='customers_v1';
const money=n=>Number(n||0).toFixed(2);

function Button({text,onPress}) {
  return <Pressable style={s.button} onPress={onPress}><Text style={s.buttonText}>{text}</Text></Pressable>;
}

export default function App() {
  const [customers,setCustomers]=useState([]);
  const [screen,setScreen]=useState('home');
  const [selected,setSelected]=useState(null);
  const [name,setName]=useState('');
  const [phone,setPhone]=useState('');
  const [balance,setBalance]=useState('');
  const [amount,setAmount]=useState('');
  const [note,setNote]=useState('');

  useEffect(()=>{ AsyncStorage.getItem(KEY).then(v=>v&&setCustomers(JSON.parse(v))); },[]);

  const save=async data=>{
    setCustomers(data);
    await AsyncStorage.setItem(KEY,JSON.stringify(data));
  };

  const addCustomer=async()=>{
    if(!name.trim()) return Alert.alert('تنبيه','أدخل اسم الزبون');
    const c={
      id:Date.now().toString(),
      name:name.trim(),
      phone:phone.trim(),
      balance:Number(balance)||0,
      history:[]
    };
    await save([...customers,c]);
    setName('');setPhone('');setBalance('');setScreen('home');
  };

  const openCustomer=c=>{setSelected(c);setScreen('customer');};

  const addPurchase=async()=>{
    const a=Number(amount)||0;
    if(!a) return;
    const data=customers.map(c=>c.id===selected.id ? {
      ...c,
      balance:c.balance+a,
      history:[...c.history,{type:'شراء',amount:a,note,date:new Date().toLocaleString()}]
    }:c);
    await save(data);
    setSelected(data.find(c=>c.id===selected.id));
    setAmount('');setNote('');setScreen('customer');
  };

  const addPayment=async()=>{
    const a=Number(amount)||0;
    if(!a) return;
    const data=customers.map(c=>c.id===selected.id ? {
      ...c,
      balance:c.balance-a,
      history:[...c.history,{type:'دفعة',amount:a,note:'',date:new Date().toLocaleString()}]
    }:c);
    await save(data);
    setSelected(data.find(c=>c.id===selected.id));
    setAmount('');setScreen('customer');
  };

  const Header=({title})=>
    <View style={s.header}><Text style={s.headerText}>{title}</Text></View>;

  if(screen==='add') return <View style={s.page}>
    <Header title="إضافة زبون"/>
    <TextInput style={s.input} placeholder="اسم الزبون" value={name} onChangeText={setName}/>
    <TextInput style={s.input} placeholder="رقم الهاتف" keyboardType="phone-pad" value={phone} onChangeText={setPhone}/>
    <TextInput style={s.input} placeholder="الرصيد / الدين" keyboardType="decimal-pad" value={balance} onChangeText={setBalance}/>
    <Button text="حفظ" onPress={addCustomer}/>
    <Button text="رجوع" onPress={()=>setScreen('home')}/>
  </View>;

  if(screen==='purchase'||screen==='payment') return <View style={s.page}>
    <Header title={screen==='purchase'?'إضافة شراء':'تسجيل دفعة'}/>
    <TextInput style={s.input} placeholder="المبلغ" keyboardType="decimal-pad" value={amount} onChangeText={setAmount}/>
    {screen==='purchase' && <TextInput style={s.input} placeholder="ماذا اشترى؟" value={note} onChangeText={setNote}/>}
    <Button text="حفظ" onPress={screen==='purchase'?addPurchase:addPayment}/>
    <Button text="إلغاء" onPress={()=>setScreen('customer')}/>
  </View>;

  if(screen==='customer'&&selected) return <ScrollView style={s.page}>
    <Header title="حساب الزبون"/>
    <Text style={s.name}>{selected.name}</Text>
    <Text style={s.info}>{selected.phone}</Text>
    <Text style={s.balance}>الرصيد: {money(selected.balance)} ₪</Text>
    <Button text="＋ إضافة شراء" onPress={()=>setScreen('purchase')}/>
    <Button text="💵 تسجيل دفعة" onPress={()=>setScreen('payment')}/>
    <Text style={s.section}>السجل</Text>
    {selected.history.slice().reverse().map((h,i)=>
      <View style={s.card} key={i}>
        <Text style={s.row}>{h.type} — {money(h.amount)} ₪</Text>
        <Text style={s.row}>{h.note||''}</Text>
        <Text style={s.date}>{h.date}</Text>
      </View>
    )}
    <Button text="رجوع" onPress={()=>setScreen('home')}/>
  </ScrollView>;

  return <View style={s.page}>
    <Header title="حسابات المحل"/>
    <Button text="＋ إضافة زبون جديد" onPress={()=>setScreen('add')}/>
    <FlatList
      data={customers}
      keyExtractor={x=>x.id}
      ListEmptyComponent={<Text style={s.empty}>لا يوجد زبائن بعد</Text>}
      renderItem={({item})=>
        <Pressable style={s.card} onPress={()=>openCustomer(item)}>
          <Text style={s.name}>{item.name}</Text>
          <Text style={s.row}>{item.phone}</Text>
          <Text style={s.balanceSmall}>الرصيد: {money(item.balance)} ₪</Text>
        </Pressable>
      }
    />
  </View>;
}

const s=StyleSheet.create({
  page:{flex:1,padding:16,backgroundColor:'#f5f5f5'},
  header:{height:64,backgroundColor:'#1565c0',justifyContent:'center',paddingHorizontal:16,margin:-16,marginBottom:16},
  headerText:{color:'#fff',fontSize:24,fontWeight:'bold',textAlign:'right'},
  input:{backgroundColor:'#fff',borderWidth:1,borderColor:'#ddd',borderRadius:8,padding:14,fontSize:17,marginBottom:12,textAlign:'right'},
  button:{backgroundColor:'#1565c0',padding:15,borderRadius:8,marginBottom:10},
  buttonText:{color:'#fff',fontSize:17,textAlign:'center',fontWeight:'bold'},
  card:{backgroundColor:'#fff',padding:16,borderRadius:10,marginBottom:10},
  name:{fontSize:21,fontWeight:'bold',textAlign:'right'},
  row:{fontSize:16,textAlign:'right',marginTop:4},
  info:{fontSize:17,textAlign:'right',marginTop:4},
  balance:{fontSize:22,fontWeight:'bold',marginVertical:14,textAlign:'right'},
  balanceSmall:{fontSize:17,fontWeight:'bold',marginTop:6,textAlign:'right'},
  section:{fontSize:20,fontWeight:'bold',marginVertical:12,textAlign:'right'},
  date:{color:'#777',marginTop:5,textAlign:'right'},
  empty:{textAlign:'center',fontSize:18,marginTop:40}
});
